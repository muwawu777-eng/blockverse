# BlockVerse – dépôt prêt à envoyer sur GitHub

## Sur téléphone ou ordinateur (environ 10 minutes)
1. GitHub > **New repository** > nom `blockverse` > **Private** > Create.
2. **uploading an existing file** : sélectionne TOUS les fichiers du dossier (ils sont à plat, sans sous-dossier) puis Commit.
3. **Add file > Create new file** : nom `.github/workflows/android.yml`, colle le contenu de `android-workflow.yml`, Commit. (Sur ordinateur, glisser le dossier `.github` fait la même chose.)
4. Le serveur Render est déjà créé (adresse déjà inscrite dans `index.html`). Rien à faire.
5. GitHub > Settings > Secrets and variables > Actions > crée `KEYSTORE_PASSWORD` (un mot de passe de ton choix).
6. Onglet **Actions** > « Construire l'AAB » > Run workflow. À la fin, télécharge l'artefact : `app-release.aab`, et au 1er passage `keystore-base64.txt`.
7. Enregistre le contenu de `keystore-base64.txt` dans le secret `KEYSTORE_B64` et **garde-le aussi en lieu sûr** (sans cette clé, impossible de mettre à jour l'app).
8. Play Console : crée l'app, envoie l'AAB, ajoute `icone-512.png` et l'image de présentation (dossier `images-play-store`), remplis la politique de confidentialité (`privacy-policy.html` : [NOM], [EMAIL], [DATE]), la classification et la sécurité des données.

Avant de lancer : remplace `com.tonnom.blockverse` dans `capacitor.config.json` par ton identifiant définitif. Lis les lignes `REPORT` des journaux Render : ce sont les signalements du chat.
